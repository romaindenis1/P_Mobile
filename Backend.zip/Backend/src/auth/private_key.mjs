// Clé privée pour signer/verifier les tokens
const privateKey = "meow";

// Export de la clé pour l'utiliser ailleurs
export { privateKey };
