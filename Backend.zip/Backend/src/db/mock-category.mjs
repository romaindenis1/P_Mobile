// Tableau des catégories
const categories = [
  {
    categorie_id: 1,
    libelle: "Philosophie",
  },
  {
    categorie_id: 2,
    libelle: "Politique",
  },
  {
    categorie_id: 3,
    libelle: "Science-fiction",
  },
  {
    categorie_id: 4,
    libelle: "Dessin",
  },
  {
    categorie_id: 5,
    libelle: "Dark fantasy",
  },
];
// Export des catégories pour pouvoir les utiliser ailleurs
export default categories;
