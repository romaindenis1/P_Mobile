// Liste des éditeurs avec identifiant et nom
const editeurs = [
  { editeur_id: 1, nom: "Pocket" },
  { editeur_id: 2, nom: "FortniteBG Publishing" },
  { editeur_id: 3, nom: "Hakusensha" },
];

// Export pour pouvoir utiliser la liste dans d'autres fichiers
export default editeurs;
