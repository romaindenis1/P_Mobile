// Liste d'auteurs avec leur identifiant et nom
const auteurs = [
  { auteur_id: 1, nom: "Théodore Kaczynski" },
  { auteur_id: 2, nom: "George Orwell" },
  { auteur_id: 3, nom: "Aldous Huxley" },
  { auteur_id: 4, nom: "Marc Aurèle" },
  { auteur_id: 5, nom: "FortniteBG Publishing" },
  { auteur_id: 6, nom: "Kentaro Miura" },
  { auteur_id: 7, nom: "Ellison Harlan" },
];

// Export de la liste pour l'utiliser dans d'autres fichiers
export default auteurs;
